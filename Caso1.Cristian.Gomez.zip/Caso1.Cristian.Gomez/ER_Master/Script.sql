
/* Drop Tables */

DROP TABLE IF EXISTS ide_cuidador;
DROP TABLE IF EXISTS zoo_especies;
DROP TABLE IF EXISTS hab_habitats;
DROP TABLE IF EXISTS ide_zona;
DROP TABLE IF EXISTS inf_tour;
DROP TABLE IF EXISTS ide_guia;
DROP TABLE IF EXISTS ide_numerico;
DROP TABLE IF EXISTS ide_visitas;
DROP TABLE IF EXISTS vis_visitantes;




/* Create Tables */

CREATE TABLE hab_habitats
(
	-- Habitat de la especie
	hab_especie varchar NOT NULL,
	-- Identificador unico de los habitats
	identificador_unico varchar,
	-- Nombre de la especie y habitat
	hab_nombre ,
	-- Clima y tipo de vegetacion predominante
	clima_tipo_vegetacion varchar,
	-- Continentes numerados
	had_continente varchar(5),
	PRIMARY KEY (hab_especie)
) WITHOUT OIDS;


CREATE TABLE ide_cuidador
(
	-- Nombre completo del cuidador
	cui_nombre varchar NOT NULL,
	-- direccion del cuidador
	cui_direccion varchar,
	cui_telefono varchar,
	-- Fecha de ingreso de cuidador
	cui_fecha_ingreso date,
	-- Especies de los animales
	esp_idespecies varchar NOT NULL,
	PRIMARY KEY (cui_nombre)
) WITHOUT OIDS;


CREATE TABLE ide_guia
(
	-- nombre del guia
	gui_nombre varchar NOT NULL,
	-- Telefono del guia
	-- 
	gui_telefono varchar,
	-- Email del guia
	gui_email varchar,
	-- Fecha de nacimiento del guia
	gui_fecha_nacimiento date,
	PRIMARY KEY (gui_nombre)
) WITHOUT OIDS;


CREATE TABLE ide_numerico
(
	-- Identificador numerico unico para cada especie
	identificador_numerico numeric(30,2) NOT NULL,
	-- Informacion de una especie exclusivamente
	informacion_especie varchar NOT NULL,
	PRIMARY KEY (identificador_numerico)
) WITHOUT OIDS;


CREATE TABLE ide_visitas
(
	-- correlativo de la visita
	correlativo_visita varchar NOT NULL,
	-- el dia de la visita
	eldia_visita varchar,
	-- razon de mas interes de la visita
	razon_interes varchar,
	PRIMARY KEY (correlativo_visita)
) WITHOUT OIDS;


CREATE TABLE ide_zona
(
	-- Nombre de la zona
	-- 
	id_nombre_zona varchar NOT NULL,
	-- Extencion del terreno
	ext_terreno varchar,
	--  Codigo del tour
	inf_codigo_tour varchar NOT NULL,
	-- correlativo de la visita
	correlativo_visita varchar NOT NULL,
	PRIMARY KEY (id_nombre_zona)
) WITHOUT OIDS;


CREATE TABLE inf_tour
(
	--  Codigo del tour
	inf_codigo_tour varchar NOT NULL,
	-- Hola inicio del tour
	tour_hora_incio varchar,
	-- Duracion y longitud del recorrido
	duracion_longitud varchar,
	-- Maximo numero de visitantes que se pueden inscribir
	max_numero_visitantes varchar,
	-- nombre del guia
	gui_nombre varchar NOT NULL,
	-- Identificacion del visitante
	id_visitante varchar NOT NULL,
	PRIMARY KEY (inf_codigo_tour)
) WITHOUT OIDS;


CREATE TABLE vis_visitantes
(
	-- Identificacion del visitante
	id_visitante varchar NOT NULL,
	-- Nombre completo del visitante
	vis_nombre1 varchar,
	vis_nombre2 varchar,
	vis_apellido1 varchar,
	vis_apellio2 varchar,
	-- Fecha de nacimiento del visitante
	vis_fecha_nacimiento date,
	-- Direccion del visitante
	vis_direccion varchar,
	PRIMARY KEY (id_visitante)
) WITHOUT OIDS;


CREATE TABLE zoo_especies
(
	-- Especies de los animales
	esp_idespecies varchar NOT NULL,
	-- Nombre de la especie
	esp_nombre varchar,
	-- Fecha de ingreso de la especie
	esp_fecha_ingreso date,
	-- Estado de la especie
	esp_estado varchar,
	-- Ancho y largo maximo que alcanzan
	esp_ancho_largo_maximo varchar,
	-- Promedio de vida de la especie
	esp_promedio_vida varchar,
	-- Habitat de la especie
	hab_especie varchar NOT NULL,
	-- Habitat de la especie
	hab_especie varchar NOT NULL,
	-- Nombre de la zona
	-- 
	id_nombre_zona varchar NOT NULL,
	-- Identificador numerico unico para cada especie
	identificador_numerico numeric(30,2) NOT NULL,
	PRIMARY KEY (esp_idespecies)
) WITHOUT OIDS;



/* Create Foreign Keys */

ALTER TABLE zoo_especies
	ADD CONSTRAINT r_habitats_especies FOREIGN KEY (hab_especie)
	REFERENCES hab_habitats (hab_especie)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;


ALTER TABLE inf_tour
	ADD CONSTRAINT r_guia_tour FOREIGN KEY (gui_nombre)
	REFERENCES ide_guia (gui_nombre)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;


ALTER TABLE zoo_especies
	ADD CONSTRAINT r_identificador_especie FOREIGN KEY (identificador_numerico)
	REFERENCES ide_numerico (identificador_numerico)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;


ALTER TABLE ide_zona
	ADD CONSTRAINT r_visitante_zona FOREIGN KEY (correlativo_visita)
	REFERENCES ide_visitas (correlativo_visita)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE zoo_especies
	ADD CONSTRAINT r_zona_especies FOREIGN KEY (id_nombre_zona)
	REFERENCES ide_zona (id_nombre_zona)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;


ALTER TABLE ide_zona
	ADD CONSTRAINT r_tour_zona FOREIGN KEY (inf_codigo_tour)
	REFERENCES inf_tour (inf_codigo_tour)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;


ALTER TABLE inf_tour
	ADD CONSTRAINT r_visitantes_tour FOREIGN KEY (id_visitante)
	REFERENCES vis_visitantes (id_visitante)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;


ALTER TABLE ide_cuidador
	ADD CONSTRAINT r_especie_cuidador FOREIGN KEY (esp_idespecies)
	REFERENCES zoo_especies (esp_idespecies)
	ON UPDATE CASCADE
	ON DELETE NO ACTION
;



/* Comments */

COMMENT ON COLUMN hab_habitats.hab_especie IS 'Habitat de la especie';
COMMENT ON COLUMN hab_habitats.identificador_unico IS 'Identificador unico de los habitats';
COMMENT ON COLUMN hab_habitats.hab_nombre IS 'Nombre de la especie y habitat';
COMMENT ON COLUMN hab_habitats.clima_tipo_vegetacion IS 'Clima y tipo de vegetacion predominante';
COMMENT ON COLUMN hab_habitats.had_continente IS 'Continentes numerados';
COMMENT ON COLUMN ide_cuidador.cui_nombre IS 'Nombre completo del cuidador';
COMMENT ON COLUMN ide_cuidador.cui_direccion IS 'direccion del cuidador';
COMMENT ON COLUMN ide_cuidador.cui_fecha_ingreso IS 'Fecha de ingreso de cuidador';
COMMENT ON COLUMN ide_cuidador.esp_idespecies IS 'Especies de los animales';
COMMENT ON COLUMN ide_guia.gui_nombre IS 'nombre del guia';
COMMENT ON COLUMN ide_guia.gui_telefono IS 'Telefono del guia
';
COMMENT ON COLUMN ide_guia.gui_email IS 'Email del guia';
COMMENT ON COLUMN ide_guia.gui_fecha_nacimiento IS 'Fecha de nacimiento del guia';
COMMENT ON COLUMN ide_numerico.identificador_numerico IS 'Identificador numerico unico para cada especie';
COMMENT ON COLUMN ide_numerico.informacion_especie IS 'Informacion de una especie exclusivamente';
COMMENT ON COLUMN ide_visitas.correlativo_visita IS 'correlativo de la visita';
COMMENT ON COLUMN ide_visitas.eldia_visita IS 'el dia de la visita';
COMMENT ON COLUMN ide_visitas.razon_interes IS 'razon de mas interes de la visita';
COMMENT ON COLUMN ide_zona.id_nombre_zona IS 'Nombre de la zona
';
COMMENT ON COLUMN ide_zona.ext_terreno IS 'Extencion del terreno';
COMMENT ON COLUMN ide_zona.inf_codigo_tour IS ' Codigo del tour';
COMMENT ON COLUMN ide_zona.correlativo_visita IS 'correlativo de la visita';
COMMENT ON COLUMN inf_tour.inf_codigo_tour IS ' Codigo del tour';
COMMENT ON COLUMN inf_tour.tour_hora_incio IS 'Hola inicio del tour';
COMMENT ON COLUMN inf_tour.duracion_longitud IS 'Duracion y longitud del recorrido';
COMMENT ON COLUMN inf_tour.max_numero_visitantes IS 'Maximo numero de visitantes que se pueden inscribir';
COMMENT ON COLUMN inf_tour.gui_nombre IS 'nombre del guia';
COMMENT ON COLUMN inf_tour.id_visitante IS 'Identificacion del visitante';
COMMENT ON COLUMN vis_visitantes.id_visitante IS 'Identificacion del visitante';
COMMENT ON COLUMN vis_visitantes.vis_nombre1 IS 'Nombre completo del visitante';
COMMENT ON COLUMN vis_visitantes.vis_fecha_nacimiento IS 'Fecha de nacimiento del visitante';
COMMENT ON COLUMN vis_visitantes.vis_direccion IS 'Direccion del visitante';
COMMENT ON COLUMN zoo_especies.esp_idespecies IS 'Especies de los animales';
COMMENT ON COLUMN zoo_especies.esp_nombre IS 'Nombre de la especie';
COMMENT ON COLUMN zoo_especies.esp_fecha_ingreso IS 'Fecha de ingreso de la especie';
COMMENT ON COLUMN zoo_especies.esp_estado IS 'Estado de la especie';
COMMENT ON COLUMN zoo_especies.esp_ancho_largo_maximo IS 'Ancho y largo maximo que alcanzan';
COMMENT ON COLUMN zoo_especies.esp_promedio_vida IS 'Promedio de vida de la especie';
COMMENT ON COLUMN zoo_especies.hab_especie IS 'Habitat de la especie';
COMMENT ON COLUMN zoo_especies.hab_especie IS 'Habitat de la especie';
COMMENT ON COLUMN zoo_especies.id_nombre_zona IS 'Nombre de la zona
';
COMMENT ON COLUMN zoo_especies.identificador_numerico IS 'Identificador numerico unico para cada especie';



